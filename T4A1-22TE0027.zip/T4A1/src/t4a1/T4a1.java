package t4a1;

import java.util.Scanner;

public class T4a1 {

    public static void main(String[] args) {

        //ejercicio1();

        //1. Escribir un programa que solicite un n�mero positivo y nos muestre desde 1 hasta el valor ingresado de uno en uno.
        //Ejemplo: Si ingresamos 30 se debe mostrar en pantalla los n�meros del 1 al 30.
        //ejercicio2();
        //2. Una maquiladora confecciona pantalones y recibe un lote de N piezas para un cliente X.
        //Crear un programa en Java que solicite la cantidad de piezas a confeccionar y
        //luego se ingrese las respectivas tallas que pueden ser S, M, L y XL.Luego,
        //imprimir en pantalla la cantidad de piezas confeccionadas por talla.
        ejercicio3();
        //3. Escribir un programa en Java que solicite N calificaciones de estudiantes en una escala del 0 al 100
        //y que informe cu�ntos tienen calificaci�n mayor o igual a 70 y cu�ntos tienen una calificaci�n menor. 
        //ejercicio4();
        //4. Escribir un programa en Java que imprima los m�ltiplos del n�mero que indique el usuario hasta la cantidad deseada.
        //El usuario debe indicar el m�ltiplo y el n�mero hasta el cual quiere llegar.
    }

    public static void ejercicio1() {

        Scanner sc = new Scanner(System.in);
        int numero;

        System.out.print("Ingrese el numero que desea enlistar:"
                + "\n");
        numero = sc.nextInt();

        int numero_inicial = 1;

        while (numero_inicial <= numero) {
            System.out.println(numero_inicial);
            numero_inicial++;

        }

    }

    public static void ejercicio2() {

        Scanner sc = new Scanner(System.in);

        System.out.print("Numero de piezas: ");
        int npiezas = sc.nextInt();
        int n = 0, tallaS = 0, tallaM = 0, tallaL = 0, tallaXL = 0;

        while (n < npiezas) {
            n++;
            System.out.print("\nTalla ");
            String talla = sc.next();

            if (talla.equals("S") || talla.equals("s")) {
                tallaS++;

            } else if (talla.equals("M") || talla.equals("m")) {
                tallaM++;

            } else if (talla.equals("L") || talla.equals("l")) {
                tallaL++;

            } else if (talla.equals("XL") || talla.equals("xl")) {
                tallaXL++;

            } else {
            }

            System.out.print("Cantidades en Talla: \n" + "Chica (S)\t\t" + tallaS + "\n" + "Mediana (M)\t\t" + tallaM + "\n" + "Grande (G)\t\t" + tallaL + "\n" + "Extragrande (XL)\t\t"
                    + tallaXL + "\n");
        }
    }

    public static void ejercicio3() {

        Scanner scanner = new Scanner(System.in);

        int calificacion;
        int i = 1;
        int contador1 = 0;
        int contador2 = 0;

        while (i <= 10) {

            System.out.println("Ecriba la " + i + "� calificaci�n: ");
            calificacion = scanner.nextInt();

            if (calificacion >= 70) {
                contador1++;

            } else if (calificacion < 70) {
                contador2++;
            }

            i++;
        }

       
        System.out.println("\nLas calificaciones mayores o iguales a 70 son: " + contador1);
        System.out.println("Las calificaciones menroes a 70 son: " + contador2);
        System.out.println("Espero te haya sido de ayuda");

    }

    public static void ejercicio4() {

        Scanner scanner = new Scanner(System.in);

        int i = 0;

        while (i++ <= 100) {

            System.out.println(i);

            if (i % 3 == 0) {
                System.out.println("Este numero es multiplo de 3. ");
            }
        }
    }

}
